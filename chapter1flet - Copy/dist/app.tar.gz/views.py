from flet import *
from pages.home import Home


def views_handler(page):
  return {
    '/':View(
        route='/',
        bgcolor ='#1E0A59',
        controls=[
          Home(page)
        ]
      ),
    
  }